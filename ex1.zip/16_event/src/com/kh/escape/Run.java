package com.kh.event.ex;

public class Run {

	public static void main(String[] args) {
		new MainFrame();	//JFrame ����

	}

}
